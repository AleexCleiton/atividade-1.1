numero=prompt("digite um numero: ");
if(numero % 2 ){
    alert("Esse numero é impar")
}else{
alert("Esse numero é par")}
