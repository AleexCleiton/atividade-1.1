for (i = 1; i <= 5; i++){
    alert(i)
}