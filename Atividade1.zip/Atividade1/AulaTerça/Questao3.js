altura =prompt("digite sua altura: ");
peso=prompt("digite seu peso: ");

imc = peso / (altura*altura);
alert(imc)

